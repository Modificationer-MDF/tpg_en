# -*- coding: utf-8 -*-
import os
import random
import time
import sys

color = {
    "red": "\033[1;31m",
    "green": "\033[1;32m",
    "yellow": "\033[1;33m",
    "blue": "\033[1;34m",
    "purple": "\033[1;35m",
    "cyan": "\033[1;36m",
    "white": "\033[1;37m",
    "reset": "\033[0m",
    }

os.chdir(os.path.dirname(os.path.abspath(__file__)))
path = os.getcwd() + "\\结果.txt"

played = False

def char(a):
    a = ">>> " + a
    for i in a:
        print(i, end = "", flush = True)
        time.sleep(0.04)
    input()

def colorstring(b, c):
    b = ">>> " + b
    for i in b:
        print(f"{color[c]}{i}{color['reset']}", end = "", flush = True)
        time.sleep(0.04)
    input()

def q7(isup, quality):  # 主线
    colorstring("老师：“接下来我来检查你们制作的 PPT 是否符合要求。”", "red")
    char("没过多久，老师就查到你的了。")
    emotion = ""
    if isup == True:
        if quality == "high":
            colorstring("老师：“你的 PPT 质量很高，很棒！”", "green")
            emotion = "happy"
        elif quality == "low":
            colorstring("老师：“你是在糊弄我吗？你的 PPT 做得很糟糕！”", "red")
            emotion = "so-so"
    else:
        colorstring("老师：“你为什么没有上传 PPT？没做？”", "red")
        colorstring("老师：“给我过来！立刻！”", "red")
        emotion = "mad"
    char("不一会，下课铃就打响了。")
    if emotion == "happy":
        char("第二天，老师将你们的作品在班上展示。同学们对你们的作品十分欣赏。")
        colorstring("恭喜你通关了本 “游戏”！", "cyan")
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write("通关。")
        except Exception as e:
            colorstring(f"无法写入结局内容。发生了错误：{e}。请重新创建文件或尝试其他方法。", "red")
            colorstring("如果本错误持续出现，请自行粘贴以下文字到 “结果.txt” 文件中：“通关。”", "cyan")
        finally:
            sys.exit()
    elif emotion == "so-so":
        char("你被老师叫到办公室去，并要求你完成一个像样的 PPT。")
        char("你最终还是做出来了，尽管勉强能看……")
        char("尽管老师对你的 PPT 评价不高，但却没被其教训。")
        colorstring("你勉强通过了本 “游戏”。", "yellow")
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write("勉强通过。")
        except Exception as e:
            colorstring(f"无法写入结局内容。发生了错误：{e}。请重新创建文件或尝试其他方法。", "red")
            colorstring("如果本错误持续出现，请自行粘贴以下文字到 “结果.txt” 文件中：“勉强通过。”", "yellow")
        finally:
            sys.exit()
    else:
        char("老师将你叫到德育处去，找到班主任。")
        if played == True:
            char("老师反馈了你在课上 “玩游戏” 的情况。班主任听到后十分生气，要求你写一份 1000 字的检讨并将其告诉了你父母。")
            char("晚上，你不敢打开家门。但过了一会，你还是打开了。")
            colorstring("你父母得知你在课上 “玩游戏”，十分震惊。狠狠地教训了你一顿并砸了你的电脑。", "red")
            char("深夜，你睡不着，你期待这一切只是一场 “梦”……")
            try:
                with open(path, "w", encoding="utf-8") as f:
                    f.write("你怎么敢在课上玩游戏？！")
            except Exception as e:
                colorstring(f"无法写入结局内容。发生了错误：{e}。请重新创建文件或尝试其他方法。", "red")
                colorstring("如果本错误持续出现，请自行粘贴以下文字到 “结果.txt” 文件中：“你怎么敢在课上玩游戏？！”", "red")
            finally:
                sys.exit()
        else:
            char("老师反馈了你在课上发呆的情况。班主任听到后十分生气，要求你写一份 800 字的检讨并将其告诉了你父母。")
            char("晚上，你不敢打开家门。但过了一会，你还是打开了。")
            colorstring("你父母得知你在课上发呆，十分震惊。对你精神洗脑。", "red")
            char("尽管如此，你仍期待明天一切都会变得更好……")
            try:
                with open(path, "w", encoding="utf-8") as f:
                    f.write("为什么在课上发呆！？")
            except Exception as e:
                colorstring(f"无法写入结局内容。发生了错误：{e}。请重新创建文件或尝试其他方法。", "red")
                colorstring("如果本错误持续出现，请自行粘贴以下文字到 “结果.txt” 文件中：“为什么在课上发呆！？”", "blue")
            finally:
                sys.exit()

def q6(): # 没有做 PPT 的分支
    char("你没有做 PPT，补做吗？（S - 是； F - 否）")
    ans6 = input("\/ ")
    match ans6:
        case "S":
            char("你决定补做 PPT。虽然质量很低，但好歹也做了。")
            char("你上传了 PPT。")
            q7(True, "low")
        case "F":
            char("好吧。")
            q7(False, "none")
        case _:
            colorstring("请重新输入。", "purple")
            q6()

def q5(comp): # 主线
    colorstring("老师：“大家的 PPT 完成了没有？时间已经到了。”", "red")
    char("老师即将要求上传 PPT ，上传吗？ （S - 上传； B - 不上传）")
    ans5 = input("\/ ")
    match ans5:
        case "S":
            if (comp == True):
                char("你已经上传了你制作的 PPT。")
                q7(True, "high")
            else:
                q6()
        case _:
            char("你决定不上传 PPT。")
            q7(False, "none")

def q4(): # 在 q3 内，选择了 “Y”
    ans4 = input("\/ ")
    match ans4:
        case "D":
            char("你打开了演示文稿并与同桌共同完成制作。在同桌的帮助下，没有什么困难的了。")
            q5(True) # 已完成
        case "C":
            char("你撤回了刚才的决定。")
            q5(False) # 未完成
        case _:
            colorstring("请重新输入。", "purple")
            q4()

def q3(): # 主线
    global played
    char("接下来，你想做什么呢？ （J - 在 CMD 中折腾； B - 保持沉默；Y - 与同桌讨论课程内容）")
    ans3 = input("\/ ")
    match ans3:
        case "J":
            char("你决定继续在 CMD 中折腾。")
            os.system("start cmd.exe")
            played = True
            q5(False)
        case "B":
            q5(False)
        case "Y":
            char("你决定与同桌讨论课程内容。这节课是 PowerPoint 的教学，所以你决定…… （D - 打开 PowerPoint 并与其讨论演示文稿的制作方法；C - 撤回刚才的决定）")
            q4()
        case _:
            colorstring("请重新输入。", "purple")
            q3()

def q2(): # q1 选择了 “暂停课堂”
    global played
    ans2 = input("\/ ")
    match ans2:
        case "B":
            char("过了一会，老师又继续开始上课了。")
            q3()
        case "D":
            colorstring("Win + [R], CMD", "cyan")
            os.system("start cmd.exe")
            played = True
            q3()
        case _:
            colorstring("请重新输入。", "purple")
            q2()

def q1(): # 第 1 个问题
    ans1 = input("\/ ")
    match ans1:
        case "Z":
            colorstring("老师：“是谁在哪里叽叽喳喳不停？” （B - 保持沉默；D - 打开 CMD）", "red")
            q2()
        case "B":
            char("老师将极域电子课堂的 “保持安静” 模式打开了并持续 1 分钟。")
            for i in range(60):
                print(".", end = "", flush = True)
                time.sleep(1)
            print()
            colorstring("是时候继续了。", "yellow")
            q3()
        case _:
            colorstring("请重新输入。", "purple")
            q1()

os.system("title 微机课上……")
char("现在正在上微机课。旁边的同学叽叽喳喳不绝，彻底盖过了老师的声音。")
char("你非常害怕，因为老师将要…… （Z - 暂停课堂； B - “保持安静”）")
q1()