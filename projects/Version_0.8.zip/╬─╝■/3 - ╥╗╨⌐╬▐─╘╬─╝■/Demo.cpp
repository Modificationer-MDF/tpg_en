﻿/* 令人忍俊不禁 */

/* 笑点解析：该文件中几乎一半都是注释和空行  :D */
/* 真代码将用多行注释标注 */

/* 《宏孩儿》滥用宏定义，做出的 “中文编程”（仿宋 - 倾斜） */

// 但是，单行注释用什么 “/* */” 啊 

// 接下来是正式代码
// 伪代码将用单行注释标注
/* 真代码将用多行注释标注 */
// #define 包含 include
// #define 使用 using
// #define 命名空间 namespace

/* 下面是头文件（乱写的  XD） */

#include <iostream>
// # 包含 <iostream>
#include <cstdio>
// # 包含 <cstdio>
#include <fstream>
// # 包含 <fstream>
#include <algorithm>
// # 包含 <algorithm>
#include <cmath>
// # 包含 <cmath>
#include <deque>
// # 包含 <deque>
#include <vector>
// # 包含 <vector>
#include <queue>
// # 包含 <queue>
#include <string>
// # 包含 <string>
#include <cstring>
// # 包含 <cstring>
#include <map>
// # 包含 <map>
#include <stack>
// # 包含 <stack>
#include <set>
// # 包含 <set>
#include <windows.h>
// # 包含 <windows.h>
#include <stdio.h>
// # 包含 <stdio.h>
using namespace std;
// 使用 命名空间 std;

/* 下面是宏定义 */
#define 输出 cout
#define 输入 cin
#define 主函数 main
#define 返回 return
#define 零 0
#define 一 1
#define 二 2
#define 三 3
#define 四 4
#define 五 5
#define 六 6
#define 七 7
#define 八 8
#define 九 9
#define 十 10
#define 赋值 =
#define 如果 if
#define 且或 else if
#define 否则 else
#define 循环 for
#define 甲 a
#define 乙 i
#define 自增 ++
#define 换行 endl
#define 整数 int
#define 浮点 double
#define 丙 b
#define 丁 c
#define 五位小数 5.44111
#define 等于 ==
#define 小于 <
#define 大于 >
#define 小于等于 <=
#define 大于等于 >=
#define 并且 &&
#define 或者 ||
#define 空格 " "
#define 打印 printf

/* 接下来来到主函数入口 */

整数 主函数()
/* int main() */
{   
  浮点 丙 赋值 五位小数;
  /* double b = 5.44111; */
  整数 甲 赋值 零;
  /* int a = 0; */
  整数 丁;
  /* int c; */
  输出 << "输入一个数字：";
  /* cout << "输入一个数字"; */
  输入 >> 丁;
  /* cin >> c; */
  循环(整数 乙 赋值 甲; 乙 小于等于 九; 乙 自增)
  /* for(int i = a; i <= 9; i++) */
  {
      输出 << 一 << 空格;
      /* cout << 1 << " "; */
      输出 << 二 << 空格;
      /* cout << 2 << " "; */
      输出 << 一 + 二 << 换行;
      /* cout << 1 + 2 << endl; */
      打印("接下来，变量丙的结果是： \n");
      /* printf("接下来，变量丙的结果是： \n"); */
      如果(丙 + 甲 等于 五位小数 或者 甲 等于 零)
      /* if(b + a == 5.44111 || a == 0) */
      {
          输出 << 丙 << 换行;
          /* cout << b << endl; */
      }
      且或(丙 + 甲 大于 五位小数 并且 甲 小于 零)
      /* else if(b + a > 5.44111 && a < 0) */
      {
          打印("变量丙的结果是： \n");
          /* printf("变量丙的结果是： \n"); */
          输出 << 丙 * 丁 ;
          /* cout << b * c; */
      }
      否则
      /* else */
      {
          打印("变量丙的结果乘方为： \n");
          /* printf("变量丙的结果乘方为： \n"); */
          输出 << 丙 * 丙;
          /* cout << b * b; */
      }
  }
  返回 零;
  /* return 0 */
}